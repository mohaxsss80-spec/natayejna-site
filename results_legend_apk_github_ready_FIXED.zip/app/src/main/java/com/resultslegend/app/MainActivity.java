package com.resultslegend.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
    private WebView web;
    private ProgressBar progress;

    private static final String SITE = "https://mhazim929282.pythonanywhere.com/";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 23, 32));

        web = new WebView(this);
        progress = new ProgressBar(this);
        progress.setIndeterminate(true);

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        FrameLayout.LayoutParams pLp = new FrameLayout.LayoutParams(96, 96);
        pLp.gravity = android.view.Gravity.CENTER;

        root.addView(web, webLp);
        root.addView(progress, pLp);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                injectPolish(view);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        web.loadUrl(SITE);
    }

    private void injectPolish(WebView view) {
        String js =
            "(function(){" +
            "var css=document.createElement('style');" +
            "css.innerHTML=`" +
            "html,body{background:#0b1720!important;}" +
            "body{font-family:system-ui,-apple-system,'Noto Naskh Arabic',sans-serif!important;}" +
            "button,input,select{font-family:inherit!important;}" +
            "button{transition:transform .12s ease,filter .12s ease!important;}" +
            "button:active{transform:scale(.98)!important;filter:brightness(.92)!important;}" +
            ".rl-icon{display:inline-flex;vertical-align:middle;margin-left:10px;width:28px;height:28px;align-items:center;justify-content:center;}" +
            ".rl-icon svg{width:26px;height:26px;fill:currentColor;}" +
            "`;document.head.appendChild(css);" +

            // Remove common emoji ranges from visible text.
            "function clean(t){return t.replace(/[\\u{1F300}-\\u{1FAFF}\\u{2600}-\\u{27BF}\\u{1F1E6}-\\u{1F1FF}]/gu,'').replace(/\\s{2,}/g,' ').trim();}" +

            // Add simple vector icons based on Arabic labels, without external image downloads.
            "function iconFor(t){t=clean(t);" +
            "if(t.includes('أدبي'))return '<svg viewBox=\"0 0 24 24\"><path d=\"M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21V5.5zM6.5 5A.5.5 0 0 0 6 5.5V17h12V5H6.5z\"/></svg>';" +
            "if(t.includes('علمي'))return '<svg viewBox=\"0 0 24 24\"><path d=\"M9 3h6v2h-1v3.2l5.3 8.6A2.8 2.8 0 0 1 17 21H7a2.8 2.8 0 0 1-2.3-4.2L10 8.2V5H9V3zm3 7-5 7.9a.8.8 0 0 0 .7 1.1h10a.8.8 0 0 0 .7-1.1L13 10h-1z\"/></svg>';" +
            "if(t.includes('بحث'))return '<svg viewBox=\"0 0 24 24\"><path d=\"m10 18 2-2-4-4 4-4-2-2-6 6 6 6zm6.5-1.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zm0-2a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z\"/></svg>';" +
            "return '<svg viewBox=\"0 0 24 24\"><path d=\"M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 5v5.6l4 2.3-1 1.7-5-3V7h2z\"/></svg>';" +
            "}" +

            "document.querySelectorAll('button,a').forEach(function(b){" +
            "var old=b.textContent||'';var c=clean(old);" +
            "if(c!==old){b.textContent=c;}" +
            "if(!b.querySelector('.rl-icon')){var s=document.createElement('span');s.className='rl-icon';s.innerHTML=iconFor(c);b.insertBefore(s,b.firstChild);}" +
            "});" +
            "})();";
        view.evaluateJavascript(js, null);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
