# ResultsLegend APK

تطبيق Android خفيف يفتح نظام النتائج الحالي داخل WebView، مع واجهة محسّنة وإزالة الإيموجيات وإضافة أيقونات Vector بسيطة.

## البناء على AndroidIDE / Android Studio

1. فك الضغط.
2. افتح المجلد `results_legend_apk` كمشروع Gradle.
3. انتظر Sync.
4. اختر `app`.
5. Build > Build APK(s).

## ملاحظة مهمة

التطبيق يعتمد على الموقع الحالي:
https://mhazim929282.pythonanywhere.com/

لذلك تبقى النتائج الحقيقية وآلية البحث في الخادم نفسه، ولا توجد نتائج وهمية داخل التطبيق.


## بناء APK تلقائيًا عبر GitHub Actions

بعد رفع المشروع إلى GitHub:
1. افتح تبويب Actions.
2. اختر Build APK.
3. اضغط Run workflow.
4. انتظر حتى تنتهي المهمة.
5. افتح نتيجة التشغيل وانزل إلى Artifacts.
6. نزّل `results-legend-apk` ثم فك الضغط لتحصل على `app-debug.apk`.

لا تضع أي Tokens أو كلمات مرور أو بيانات طلاب داخل المستودع.
